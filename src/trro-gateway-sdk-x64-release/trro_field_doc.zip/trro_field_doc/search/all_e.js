var searchData=
[
  ['y0',['y0',['../structTRRO__RoiRect.html#afd88dbf360b3936e08cb6310ec2ba592',1,'TRRO_RoiRect']]],
  ['y1',['y1',['../structTRRO__RoiRect.html#a3ab5bf813af783e1b97d41adadcfa26f',1,'TRRO_RoiRect']]]
];
