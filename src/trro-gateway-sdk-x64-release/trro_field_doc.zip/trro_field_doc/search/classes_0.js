var searchData=
[
  ['trro_5froirect',['TRRO_RoiRect',['../structTRRO__RoiRect.html',1,'']]],
  ['trro_5ftextformat',['TRRO_TextFormat',['../structTRRO__TextFormat.html',1,'']]],
  ['trromultinetworkstats',['TrroMultiNetworkStats',['../structTrroMultiNetworkStats.html',1,'']]]
];
