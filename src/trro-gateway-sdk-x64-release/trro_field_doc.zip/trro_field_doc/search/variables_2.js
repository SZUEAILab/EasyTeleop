var searchData=
[
  ['point_5fx',['point_x',['../structTRRO__TextFormat.html#aade52abd51b986ed948cfad19da451b7',1,'TRRO_TextFormat']]],
  ['point_5fy',['point_y',['../structTRRO__TextFormat.html#ada2c3a6fd622781893eb194c55205bdc',1,'TRRO_TextFormat']]]
];
