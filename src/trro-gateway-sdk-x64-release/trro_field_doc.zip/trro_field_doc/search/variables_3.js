var searchData=
[
  ['qp_5fdelta',['qp_delta',['../structTRRO__RoiRect.html#ad432b6ed4ba8ffde5cd4d849311e1c39',1,'TRRO_RoiRect']]]
];
