var searchData=
[
  ['recv_5fbytes',['recv_bytes',['../structTrroMultiNetworkStats.html#a83a344be1394244eda909d438c5e257c',1,'TrroMultiNetworkStats']]],
  ['rtt',['rtt',['../structTrroMultiNetworkStats.html#abb3e7ba2cb6950a2247d51232c9348b1',1,'TrroMultiNetworkStats']]]
];
