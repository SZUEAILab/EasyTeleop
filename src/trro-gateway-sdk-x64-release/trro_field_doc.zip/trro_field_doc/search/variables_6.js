var searchData=
[
  ['text',['text',['../structTRRO__TextFormat.html#a28e8f1e64cfcffacea47b6e6881ed53d',1,'TRRO_TextFormat']]],
  ['text_5fborder_5fcolor',['text_border_color',['../structTRRO__TextFormat.html#aed058cf7c60ff89ce099065520d3e440',1,'TRRO_TextFormat']]],
  ['text_5fborder_5fsize',['text_border_size',['../structTRRO__TextFormat.html#a47f3c07ede7d95d2cb02a4bf85336b05',1,'TRRO_TextFormat']]],
  ['text_5fcolor',['text_color',['../structTRRO__TextFormat.html#a43c3ed7deddc4a27d520fa0aa5247907',1,'TRRO_TextFormat']]]
];
