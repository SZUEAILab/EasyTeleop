var searchData=
[
  ['extern_5fip',['extern_ip',['../structTrroMultiNetworkStats.html#a56d05ae7f166a75cfb5bb0a79fe86d0a',1,'TrroMultiNetworkStats']]],
  ['extern_5fport',['extern_port',['../structTrroMultiNetworkStats.html#ac9b2cea7c10ccdd8ab58545b9978d86a',1,'TrroMultiNetworkStats']]]
];
