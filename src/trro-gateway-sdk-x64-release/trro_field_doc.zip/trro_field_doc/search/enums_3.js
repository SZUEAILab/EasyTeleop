var searchData=
[
  ['trrocolor',['TrroColor',['../trro__field_8h.html#ae8d8fb732bce75fade0d9092abc1c56d',1,'trro_field.h']]],
  ['trrologlevel',['TrroLogLevel',['../trro__field_8h.html#ae5ffab6f9a737ee1a3595a4ddafbad62',1,'trro_field.h']]],
  ['trropermission',['TrroPermission',['../trro__field_8h.html#a6439338f7b52fbaf28154918aae3987f',1,'trro_field.h']]],
  ['trrostate',['TrroState',['../trro__field_8h.html#a9f2eb5ac2f6809cde8a510d10a093556',1,'trro_field.h']]]
];
