var searchData=
[
  ['local_5fip',['local_ip',['../structTrroMultiNetworkStats.html#a90abb3c7de6c68c0b35dcd146099342b',1,'TrroMultiNetworkStats']]],
  ['local_5fport',['local_port',['../structTrroMultiNetworkStats.html#a57c5dfb59670cfc46117629447b887bb',1,'TrroMultiNetworkStats']]],
  ['lost',['lost',['../structTrroMultiNetworkStats.html#a6c6966bca75b3da41c199b2f909ee889',1,'TrroMultiNetworkStats']]]
];
