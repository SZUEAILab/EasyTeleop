var searchData=
[
  ['send_5fbytes',['send_bytes',['../structTrroMultiNetworkStats.html#aa5230010cdf55eac98b22a690d6ab86a',1,'TrroMultiNetworkStats']]]
];
