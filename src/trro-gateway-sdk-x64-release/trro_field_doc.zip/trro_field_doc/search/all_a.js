var searchData=
[
  ['send_5fbytes',['send_bytes',['../structTrroMultiNetworkStats.html#aa5230010cdf55eac98b22a690d6ab86a',1,'TrroMultiNetworkStats']]],
  ['signalstate',['SignalState',['../trro__field_8h.html#ad8c9c159c48d2c3bf28f0fc98c669c9c',1,'trro_field.h']]]
];
