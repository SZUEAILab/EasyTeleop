var searchData=
[
  ['x0',['x0',['../structTRRO__RoiRect.html#a1720ee677bdc9cfe3c762a80c6dbf3f6',1,'TRRO_RoiRect']]],
  ['x1',['x1',['../structTRRO__RoiRect.html#a999fbd4540f77453af48c1be077d79fe',1,'TRRO_RoiRect']]]
];
