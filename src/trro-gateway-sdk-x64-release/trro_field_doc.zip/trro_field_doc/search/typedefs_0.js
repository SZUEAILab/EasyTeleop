var searchData=
[
  ['trro_5foncontroldata',['TRRO_onControlData',['../trro__field_8h.html#ac5250ffbbc5aed714b01474a331bc251',1,'trro_field.h']]],
  ['trro_5fonencodeframeinfo',['TRRO_onEncodeFrameInfo',['../trro__field_8h.html#af9f091c2ded227fca0f8d0a10bd700ac',1,'trro_field.h']]],
  ['trro_5fonerrorevent',['TRRO_OnErrorEvent',['../trro__field_8h.html#ab0055c87b5cdc5a14537bb361bc2b683',1,'trro_field.h']]],
  ['trro_5fonlatencyreport',['TRRO_onLatencyReport',['../trro__field_8h.html#a73fa773663dd7f8e0e97dea405ff009a',1,'trro_field.h']]],
  ['trro_5fonlogdata',['TRRO_OnLogData',['../trro__field_8h.html#a0370dd85302d6fe4d3415d7cfacf4f70',1,'trro_field.h']]],
  ['trro_5fonmediastate',['TRRO_onMediaState',['../trro__field_8h.html#a3c8ea1396c2ef8178997f33283bf83fe',1,'trro_field.h']]],
  ['trro_5fonmultinetworkstat',['TRRO_onMultiNetworkStat',['../trro__field_8h.html#a17f7292961a46732dba1b7340dbf20ee',1,'trro_field.h']]],
  ['trro_5fonoperationpermissionrequest',['TRRO_onOperationPermissionRequest',['../trro__field_8h.html#ae3e8d82db2500db2f2247513e8aec028',1,'trro_field.h']]],
  ['trro_5fonremotemixaudioframe',['TRRO_onRemoteMixAudioFrame',['../trro__field_8h.html#a06798364a03432916f1e7727862a0de6',1,'trro_field.h']]],
  ['trro_5fonsignalstate',['TRRO_onSignalState',['../trro__field_8h.html#ae44dddd6ccbc1c244e7b64a4bdf8ae7a',1,'trro_field.h']]],
  ['trro_5fonstate',['TRRO_OnState',['../trro__field_8h.html#a821cd15af91742d561cd0c8e743f24cf',1,'trro_field.h']]],
  ['trro_5fonvideocapturedata',['TRRO_onVideoCaptureData',['../trro__field_8h.html#abf4ab093d305ce565ff729e7ec133f65',1,'trro_field.h']]],
  ['trro_5fonvideocaptureframe',['TRRO_onVideoCaptureFrame',['../trro__field_8h.html#a298ba76372ff795f97a3ec56e9216cba',1,'trro_field.h']]]
];
